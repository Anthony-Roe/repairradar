// src/app/(tenant)/[tenant]/dashboard/components/DashboardHeader.tsx
"use client";
import { Button } from "@/components/ui/button";
import { Bell, Settings, User } from "lucide-react";
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@radix-ui/react-tooltip";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"; // Import Shadcn Tabs

export function DashboardHeader({
  meta,
  activeTab,
  setActiveTab,
}: DashboardHeaderProps) {
  return (
    <header className="p-4 sticky top-0 z-50 bg-background">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-lg font-bold flex items-center gap-2 tracking-tight">
            <a className="text-foreground" href="">
              {meta.name}
            </a>
          </h1>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="assets">Assets</TabsTrigger>
              <TabsTrigger value="work-orders">Work Orders</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <div className="flex items-center gap-3">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground hover:text-foreground hover:bg-primary rounded-full transition-colors"
                >
                  <Bell className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                <p className="text-xs font-medium bg-muted text-foreground px-2 py-1 rounded-md border border-border">
                  Notifications
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground hover:bg-primary rounded-full transition-colors"
          >
            <Settings className="h-5 w-5" />
          </Button>
          <Button
            variant="outline"
            className="gap-2 bg-background/5 border-border hover:bg-primary hover:text-foreground text-muted-foreground transition-colors rounded-md"
          >
            <User className="h-4 w-4" />
            <span>Profile</span>
          </Button>
        </div>
      </div>
    </header>
  );
}

interface DashboardHeaderProps {
  meta: { name: string };
  activeTab: string;
  setActiveTab: React.Dispatch<React.SetStateAction<string>>;
}