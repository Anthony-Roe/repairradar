import Link from "next/link";
import { redirect } from "next/navigation";

export default function Home() {
  console.log("Redirecting to /dashboard");
}
