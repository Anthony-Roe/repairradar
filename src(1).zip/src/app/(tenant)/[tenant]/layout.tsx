// src/app/(tenant)/[tenant]/layout.tsx
import { TenantProvider, useTenant } from "@/components/TenantProvider";
import SessionWrapper from "@/components/SessionWrapper";
import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth";
import { Session } from "next-auth";
import { cn } from "@/lib/utils";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Link from "next/link";
import { Bell, WrenchIcon } from "lucide-react";

interface TenantLayoutProps {
  children: React.ReactNode;
  dashboard?: React.ReactNode; // Parallel route slot
  analytics?: React.ReactNode; // Parallel route slot
  settings?: React.ReactNode; // Parallel route slot
  modal?: React.ReactNode; // Modal slot
  params: { tenant: string };
  session: Session;
}

const navItems = [
  {
    title: "Dashboard",
    href: ".", // Points to current route (tenant root)
  },
  {
    title: "Assets",
    href: "assets",
  },
  {
    title: "Work Orders",
    href: "work-orders",
  },
  {
    title: "Analytics",
    href: "analytics",
  },
  {
    title: "Settings",
    href: "settings",
  },
];

export default async function TenantLayout({
  children,
  dashboard,
  analytics,
  settings,
  modal,
  params,
  session,
}: TenantLayoutProps) {
  const auth = await requireAuth();
  const { tenant } = auth.user;
  console.log(auth)

  return (
    <SessionWrapper session={session}>
      <TenantProvider tenant={tenant}>
        <div className="flex min-h-screen flex-col">
          {/* Header/Navbar */}
          <header className="sticky top-0 z-40 border-b bg-background">
            <div className="container flex h-16 items-center justify-between px-4">
              <div className="flex items-center gap-6">
                <Link href={`/${tenant.subdomain}`} className="flex items-center space-x-2">
                  <WrenchIcon className="h-6 w-6" />
                  <span className="font-bold">{tenant.name}</span>
                </Link>
                
                <NavigationMenu className="hidden md:block">
                  <NavigationMenuList>
                    {navItems.map((item) => (
                      <NavigationMenuItem key={item.href}>
                        <Link href={`/${tenant.subdomain}/${item.href}`} legacyBehavior passHref>
                          <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                            {item.title}
                          </NavigationMenuLink>
                        </Link>
                      </NavigationMenuItem>
                    ))}
                  </NavigationMenuList>
                </NavigationMenu>
              </div>

              <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon">
                  <Bell className="h-5 w-5" />
                </Button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={auth.user.image || undefined} alt={auth.user.name || ""} />
                        <AvatarFallback>
                          {auth.user.name?.charAt(0) || "U"}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">{auth.user.name}</p>
                        <p className="text-xs leading-none text-muted-foreground">
                          {auth.user.email}
                        </p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href={`/${tenant.subdomain}/settings`}>Settings</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/api/auth/signout">Log out</Link>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <div className="flex flex-1">
            <main className="flex-1 overflow-auto">
              <div className="container py-6">
                {/* 
                  The @dashboard parallel route will render here when accessed via /[tenant]
                  Other parallel routes will render in their respective slots
                */}
                {children}
                {dashboard}
                {analytics}
              </div>
            </main>
          </div>

          {/* Modal slot */}
          {modal}
        </div>
      </TenantProvider>
    </SessionWrapper>
  );
}