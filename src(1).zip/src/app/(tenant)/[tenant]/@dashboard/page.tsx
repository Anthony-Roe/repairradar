// src/app/(tenant)/[tenant]/@dashboard/page.tsx
"use server";
import {
  getAssets,
  getWorkOrders,
  getMaintenanceSchedules,
  getIncidents,
  getParts,
} from "@/actions";
import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth";
import { UserRole } from "@/prisma";
import { HydrationBoundary, QueryClient, dehydrate } from "@tanstack/react-query";
import DashboardClient from "./client";
import { createQueryClient } from "@/lib/query";

export default async function Dashboard({ params }: { params: Promise<{ tenant: string }> }) {
  const { tenant: sub } = await params;
  const session = await requireAuth();
  const tenant = session.user.tenant;

  if (sub !== tenant.subdomain && !session.user.role.includes(UserRole.SUPER_ADMIN)) {
    throw new Error("You don't have access to this tenant");
  }

  const queryClient = createQueryClient();

  try {
    // Prefetch data using React Query
    await Promise.all([
      queryClient.prefetchQuery({
        queryKey: ["assets", tenant.id],
        queryFn: () => getAssets({ tenantId: tenant.id }).then((res) => res.assets),
      }),
      queryClient.prefetchQuery({
        queryKey: ["workOrders", tenant.id],
        queryFn: () => getWorkOrders({ tenantId: tenant.id }).then((res) => res.workOrders),
      }),
      queryClient.prefetchQuery({
        queryKey: ["maintenance", tenant.id],
        queryFn: () =>
          getMaintenanceSchedules({ tenantId: tenant.id }).then((res) => res.schedules),
      }),
      queryClient.prefetchQuery({
        queryKey: ["incidents", tenant.id],
        queryFn: () => getIncidents({ tenantId: tenant.id }).then((res) => res.incidents),
      }),
      queryClient.prefetchQuery({
        queryKey: ["parts", tenant.id],
        queryFn: () => getParts({ tenantId: tenant.id }).then((res) => res.parts),
      }),
    ]);

    return (
      <HydrationBoundary state={dehydrate(queryClient)}>
        <DashboardClient tenantId={tenant.id} subdomain={tenant.subdomain} />
      </HydrationBoundary>
    );
  } catch (error) {
    console.error("Dashboard error:", error);
    notFound();
  }
}