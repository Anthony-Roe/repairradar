// src/app/(tenant)/[tenant]/page

export default function MainPage() {

  return (
    <div className="p-6">
      <h2>Main tenant site!</h2>
    </div>
  );
}